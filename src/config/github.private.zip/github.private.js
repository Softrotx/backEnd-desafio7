module.exports = {
    appId: '888031',
    clientID: 'Iv1.510e3834e7482770',
    clientSecret: '06a48ccf6f09abf5fd95e3a3b1173ae1edd17f67',
    callbackURL: 'http://localhost:8080/api/sessions/githubcallback'
}